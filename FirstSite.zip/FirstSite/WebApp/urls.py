from django.urls import path
from . import views

urlpatterns = [
    path('',views.homepageview,name="home"),
    path('contact',views.contactusview,name="contact"),
    path('about',views.aboutusview,name="about"),
    path('register',views.register,name="register"),
    path('youtube',views.youtube,name="youtube"),
    path('fiverr',views.fiverr,name="fiverr"),
    path('crypto',views.crypto,name="crypto"),
    path('portfolio',views.portfolio,name="portfolio"),
    path('sumresult',views.sumresult,name="sumresult"),
]