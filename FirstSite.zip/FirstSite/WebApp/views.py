from django.shortcuts import render
from django.http import HttpResponse
from WebApp.models import Student


def homepageview(request):
    return render(request,'index.html')

def contactusview(request):
    return render(request,'contact.html')

def aboutusview(request):
    return render(request,'about.html')

def register(request):
    if request.method == 'POST':      
        fname = str(request.POST['fname'])
        email = str(request.POST['email'])
        password  = str(request.POST['password'])
        enum  = str(request.POST['enum'])
        pnum  = str(request.POST['pnum'])
        uname  = str(request.POST['uname'])
        cname  = str(request.POST['cname'])
        bname  = str(request.POST['bname'])
        snum  = str(request.POST['snum'])

        
        print(fname,email,password,enum,pnum,cname,snum,uname)

        ins = Student(fname=fname,email=email,password=password,pnum=pnum,cname=cname,uname=uname,snum=snum,enum=enum)
        ins.save()
        print("Data stored successfully")


    return render(request,'register.html')

def youtube(request):
    return render(request,'https://youtube.com/vedthemasterofficial')

def fiverr(request):
    return render(request,'https://fiverr.com.hellopthe')

def crypto(request):
    return render(request,'crypto.html')

def portfolio(request):
    return render(request,'portfolio.html')

def sumresult(request):
    print("Welcome")
    print(request.method)
    print(request.POST)
    a = int(request.POST['val1'])
    b = int(request.POST['val2'])
    c = a + b
    print(c)
    return render(request,'sumresult.html',{'fsum':c,'fa':a,'fb':b})




# Create your views here.
