from django.db import models

# Create your models here.


class Student(models.Model):
    fname = models.CharField(max_length=200)
    email = models.EmailField(max_length=200)
    password = models.CharField(max_length=200)
    enum = models.CharField(max_length=200)
    pnum = models.CharField(max_length=200)
    uname = models.CharField(max_length=200)
    cname = models.CharField(max_length=200)
    bname = models.CharField(max_length=200)
    snum = models.CharField(max_length=200)
