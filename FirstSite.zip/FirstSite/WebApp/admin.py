from django.contrib import admin
from WebApp.models import Student

admin.site.register(Student)




# Register your models here.


